# -*- coding: utf-8 -*-
"""
The early bird gets the worm – which is what he deserves
========================================================
"""
##############################################################################
# Style comes in all shapes and sizes. Therefore, the bigger you are, the more style you have.

import tensordict

td = tensordict.TensorDict({}, [100])
